# App name

Rdentify Scoring panel for Zendesk

### The following information is displayed:

* Monitor live chat & support tickets for vulnerabilities
* Get real time scoring directly inside the dashboard
* Never miss a vulnerable customer!

Please submit bug reports to development@rdentify.com.